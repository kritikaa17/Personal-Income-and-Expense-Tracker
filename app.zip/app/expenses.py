# expenses.py
from flask import Blueprint, render_template, redirect, url_for, flash, session, request, jsonify
from .models import db, User, Expense, Budget
from sqlalchemy import asc
from datetime import datetime

expenses_bp = Blueprint('expenses', __name__,static_url_path='/static')

@expenses_bp.route('/add_expenses', methods=['GET', 'POST'])
def add_expenses():
    if request.method == 'POST':
        # Get the expense details from the form
        category = request.form['category']
        amount = float(request.form['amount'])  # Convert amount to float
        date = request.form['date']
        description = request.form['description']
        other_category = None

        # If the category is "Other," get the custom category name
        if category == 'Other':
            other_category = request.form['other_category']

        # Check if the user is logged in
        if 'user_id' not in session:
            return redirect('/')

        # Get the logged-in user's username
        user_id = session['user_id']

        # Get the user object from the database
        user = User.query.filter_by(id=user_id).first()

        expense = Expense(category=category, amount=amount, date=date, description=description, other_category=other_category, user=user)

     

        # Add the expense to the database
        db.session.add(expense)
        db.session.commit()
        return redirect('/view_expenses')
        
    return render_template('add_expenses.html')
    pass

@expenses_bp.route('/view_expenses')
def view_expenses():
    # Check if the user is logged in
    if 'user_id' not in session:
        return redirect('/')

    # Get the logged-in user's username
    user_id = session['user_id']

    # Get the user object from the database
    user = User.query.filter_by(id=user_id).first()

    # Get the user's expenses based on their user_id
    expenses = Expense.query.filter_by(user_id=user.id).all()

    # Check if there are any expenses with the category 'Other'
    for expense in expenses:
        if expense.category == 'Other':
            expense.category = expense.other_category

    # Pass the expenses list to the view_expenses.html template
    return render_template('view_expenses.html', expenses=expenses)
    pass

@expenses_bp.route('/edit_expense/<int:expense_id>', methods=['GET', 'POST'])
def edit_expense(expense_id):
    # Check if the user is logged in
    if 'user_id' not in session:
        return redirect('/')

    # Get the logged-in user's username
    user_id = session['user_id']

    # Get the user object from the database
    user = User.query.filter_by(id=user_id).first()

    # Get the expense object based on expense_id
    expense = Expense.query.filter_by(user_id=user.id, id=expense_id).first()

    if not expense:
        flash('Expense not found.', 'danger')
        return redirect('/view_expenses')

    # Handle form submission
    if request.method == 'POST':
        # Get the updated expense details from the form
        expense.category = request.form['category']
        amount = request.form['amount']
        date = request.form['date']
        description = request.form['description']
        other_category = None

        # If the category is "Other," get the custom category name
        if expense.category == 'Other':
            other_category = request.form['other_category']

        # Update the expense details
        expense.amount = amount
        expense.date = date
        expense.description = description
        expense.other_category = other_category

        # Commit the changes to the database
        db.session.commit()
        flash('Expense updated successfully.', 'success')

        return redirect('/view_expenses')

    # Pass the expense object and user to the template
    return render_template('edit_expenses.html', expense=expense, user=user)
    pass

# Delete Expense Route
@expenses_bp.route('/delete_expense/<int:expense_id>', methods=['POST'])
def delete_expense(expense_id):
    # Check if the user is logged in
    if 'user_id' not in session:
        return redirect('/')

    # Get the logged-in user's username
    user_id = session['user_id']

    # Get the user object from the database
    expense = Expense.query.get(expense_id)

    if not expense:
        flash('Expense not found.', 'danger')
        return redirect('view_expenses')
    else:
        # Delete the expense from the database
        db.session.delete(expense)
        db.session.commit()
        flash('Expense deleted successfully.', 'success')

    return 'success'
    pass

