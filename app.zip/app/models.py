from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
import secrets
import random



# Define your models here
db = SQLAlchemy()


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    incomes = db.relationship('Income', back_populates='user')
    expenses = db.relationship('Expense', back_populates='user')
    budgets = db.relationship('Budget', back_populates='user')
    verification_code = db.Column(db.String(64), unique=True, nullable=True)
    is_active = db.Column(db.Boolean, default=False)

    def generate_verification_code(self):
        # Generate a unique verification code
        while True:
            code = token_hex(32)
            if not User.query.filter_by(verification_code=code).first():
                break
        self.verification_code = token_hex(32)

    def verify_email(self, code):
        print(f"Stored Verification Code: {self.verification_code}")
        print(f"Entered Verification Code: {code}")

        if self.verification_code == code:
            self.is_active = True
            self.verification_code = None
            return True
        return False


    def __repr__(self):
        return f'<User {self.username}>'

class Income(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    source = db.Column(db.String(100), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    date = db.Column(db.String(20), nullable=False)

        # Add the foreign key to User
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    # Define the relationship with User
    user = db.relationship('User', back_populates='incomes')
    
    def __init__(self, source, amount,date, user_id):
        self.source = source
        self.amount = amount
        self.date = date
        self.user_id = user_id 

class Expense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(200))  # Add the description column here
    date = db.Column(db.String(20), nullable=False)
    other_category = db.Column(db.String(255), nullable=True)

    # Define the relationship with the User model
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', back_populates='expenses')

    def __init__(self, category, amount,date, description, user,other_category=None):
        self.category = category
        self.amount = amount
        self.description = description
        self.date = date
        self.user = user
        self.other_category = other_category

class Budget(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    user = db.relationship('User', back_populates='budgets')
    amount = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(200)) 
    other_category = db.Column(db.String(255), nullable=True)

    def __repr__(self):
        return f"Budget(user_id={self.user_id}, user = {self.user}, category='{self.category}', description ='{self.description}',amount={self.amount} , other_category='{self.other_category}')"