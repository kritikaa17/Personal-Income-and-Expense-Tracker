from .models import User
from app.models import Income, Expense
from datetime import datetime


def calculate_total_expenses(user_id):
    # Get the user object from the database based on the username
    user = User.query.filter_by(id = user_id).first()

    # Calculate the total expense for the user
    total_expense = 0
    if user:
        expenses = Expense.query.filter_by(user_id=user.id).all()
        for expense in expenses:
            total_expense += expense.amount

    return total_expense


def calculate_expenses_by_category(user_id):
    # Get the user object from the database
    user = User.query.filter_by(id=user_id).first()

    # Get all expenses for the user
    expenses = Expense.query.filter_by(user_id=user.id).all()

    # Initialize a dictionary to store expenses by category
    category_expenses = {}

    # Iterate through the expenses
    for expense in expenses:
        # Determine the category to use for counting (either the primary category or other_category)
        category = expense.other_category if (expense.category == 'Other' and expense.other_category) else expense.category

        if category in category_expenses:
            category_expenses[category].append({'amount': expense.amount, 'date': expense.date})
        else:
            category_expenses[category] = [{'amount': expense.amount, 'date': expense.date}]
        
    return category_expenses



def calculate_total_income(user_id):
    # Get the user object from the database based on the username
    user = User.query.filter_by(id=user_id).first()

    # Calculate the total income for the user
    total_income = 0
    if user:
        incomes = Income.query.filter_by(user_id=user.id).all()
        for income in incomes:
            total_income += income.amount

    return total_income


def calculate_income_by_source(user_id):
    # Get the user object from the database
    user = User.query.filter_by(id=user_id).first()
    
    incomes = Income.query.filter_by(user_id=user.id).all()
    # Initialize a dictionary to store income data by source
    income_by_source = {}

    
    # Group income data by source
    for income in incomes:
        source = income.source
        

        if source in income_by_source:
            income_by_source[source].append({'amount': income.amount, 'date': income.date})
            
        else:
            income_by_source[source] = [{'amount': income.amount, 'date': income.date}]

    return income_by_source



def aggregate_income_for_pie_chart(income_data):
    aggregated_data = {}

    for source, incomes in income_data.items():
        total_income = sum(income['amount'] for income in incomes)

        aggregated_data[source] = total_income

    return aggregated_data


def aggregate_expense_for_pie_chart(expense_data):
    aggregated_data = {}

    for category, expenses in expense_data.items():
        total_expense = sum(expense['amount'] for expense in expenses)

        aggregated_data[category] = total_expense

    return aggregated_data
