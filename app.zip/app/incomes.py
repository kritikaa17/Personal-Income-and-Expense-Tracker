# incomes.py
from flask import Blueprint, render_template, redirect, url_for, flash, session, request, jsonify
from .models import db, User, Income
from datetime import datetime

incomes_bp = Blueprint('incomes', __name__,static_url_path='/static')

@incomes_bp.route('/add_income', methods=['GET', 'POST'])
def add_income():
    if request.method == 'POST':
        # Handle the form submission for adding income
        source = request.form['source']
        amount = float(request.form['amount'])
        date = request.form['date']
    
        # Check if the user is logged in
    
        if 'user_id' not in session:
            return redirect('/')
    
        user_id = session['user_id']

        # Get the user object from the database using the username from the session
        user = User.query.filter_by(id=user_id).first()

        # Create a new Income object
        new_income = Income(user_id=user.id, source=source, amount=amount, date=date)

        # Add the new income to the database
        db.session.add(new_income)
        db.session.commit()

        return redirect(url_for('incomes.view_income'))

    # Display the add income form if accessed via GET request
    return render_template('add_income.html')
    pass

@incomes_bp.route('/view_income')
def view_income():
    # Check if the user is logged in
    if 'user_id' not in session:
        return redirect('/') 

    user_id = session['user_id']

    # Get the user object from the database
    user = User.query.filter_by(id=user_id).first()
    if not user:
        flash('User not found. Please log in again.', 'error')
        return redirect('/dashboard')
    user_incomes = user.incomes if user else []

    return render_template('view_income.html', incomes=user_incomes) 
    pass

@incomes_bp.route('/edit_income/<int:income_id>', methods=['GET', 'POST'])
def edit_income(income_id):
    # Check if the user is logged in
    if 'user_id' not in session:
        return redirect('/')

    # Get the logged-in user's username
    user_id = session['user_id']

    # Get the user object from the database
    user = User.query.filter_by(id=user_id).first()

    # Get the income object based on income_id
    income = Income.query.filter_by(user_id=user.id, id=income_id).first()

    if not income:
        flash('Income not found.', 'danger')
        return redirect('/view_income')

    if request.method == 'POST':
        # Handle the form submission for updating income
        income.amount = float(request.form['amount'])
        income.date = request.form['date']
        income.source = request.form['source']

        # Update the income in the database
        db.session.commit()
        flash('Income updated successfully.', 'success')
        return redirect('/view_income')

    # Display the edit income form if accessed via GET request
    return render_template('edit_income.html', income=income)
    pass


@incomes_bp.route('/delete_income/<int:income_id>', methods=['POST'])
def delete_income(income_id):
    # Check if the user is logged in
    if 'user_id' not in session:
        return redirect('/')

    # Get the logged-in user's username
    user_id = session['user_id']

    # Get the user object from the database
    user = User.query.filter_by(id=user_id).first()

    # Get the income object based on income_id
    income = Income.query.filter_by(user_id=user.id, id=income_id).first()

    if not income:
        flash('Income not found.', 'danger')
    else:
        # Delete the income from the database
        db.session.delete(income)
        db.session.commit()
        flash('Income deleted successfully.', 'success')

    return 'success'
    pass

