# dashboard.py
from flask import Blueprint, render_template, redirect, url_for, flash, session
from .models import User, Expense, Income
from sqlalchemy import asc
from datetime import datetime

dashboard_bp = Blueprint('dashboard', __name__,static_url_path='/static')

@dashboard_bp.route('/dashboard', methods=['GET'])
def dashboard():
    if 'user_id' not in session:
        return redirect('/')

    
    # Fetch the user's ID from the session
    user_id = session['user_id']

    # Fetch the user's username from the database
    user = User.query.get(user_id)
    username = user.username if user else None

    # Replace this with your actual logic to fetch user expense and income summary
    user_expense_summary = {
        'total_expenses': 1000,
        'total_income': 2500,
        'net_income': 1500
    }

    return render_template('dashboard.html', username=username, user_expense_summary=user_expense_summary)
    pass


