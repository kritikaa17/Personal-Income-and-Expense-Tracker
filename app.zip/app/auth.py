from flask import Blueprint, render_template, redirect, url_for, flash, session, request
from app.models import db, User
import random
import string
import smtplib
from .email import send_verification_email, send_account_created_email
from werkzeug.security import check_password_hash , generate_password_hash



auth_bp = Blueprint('auth', __name__, static_url_path='/static')
user_accounts = {}

@auth_bp.route('/create_account', methods=['GET', 'POST'])
def create_account():
    if request.method == 'POST':
        new_username = request.form['new_username']
        new_password = request.form['new_password']
        email = request.form['email']

        # Check if the username already exists in the database
        existing_user = User.query.filter_by(username=new_username).first()
        if existing_user:
            account_error = "Username already exists. Please choose a different username."
            return render_template('login.html', account_error=account_error)

        existing_email = User.query.filter_by(email=email).first()
        if existing_email:
            account_error = "Email already exists. Please use a different email address."
            return render_template('login.html', account_error=account_error)

        # Generate a random verification code
        verification_code = ''.join(random.choices(string.digits, k=6))

        # Create a new user object with the verification code
        new_user = User(username=new_username, password=generate_password_hash(new_password), email=email, verification_code=verification_code)

        # Add the new user to the database
        db.session.add(new_user)
        db.session.commit()

        if send_verification_email(email, verification_code):
            # Send an email for successful account creation
            if send_account_created_email(email):
                flash('Account created successfully. Please check your email for the verification code.', 'success')
                return render_template('enter_verification_code.html', user=new_user)
            else:
                flash('Account created successfully, but email sending failed.', 'danger')
                return render_template('enter_verification_code.html', user=new_user)

        else:
            flash('Email sending failed', 'danger')

    return render_template('login.html')


# Modify the /login route to check if verification is required
@auth_bp.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        # Get the user's credentials
        username = request.form['username']
        password = request.form['password']

        # Check if the user exists
        user = User.query.filter_by(username=username).first()
        if user:
            if user.is_active:
                # User is active, check the password
                if check_password_hash(user.password, password):
                    # Password is correct, set a session variable to indicate login
                    session['user_id'] = user.id
                    flash('Login successful!', 'success')
                    return redirect(url_for('dashboard.dashboard'))
                else:
                    flash('Invalid password. Please check your username and password.', 'danger')
            else:
                # User is not active, redirect them to the verification page
                flash('Your email is not verified. Please check your email for the verification code.', 'danger')
                return redirect(url_for('auth.verify_email', user_id=user.id))  # Redirect to email verification page
        else:
            flash('User does not exist. Please create an account.', 'danger')

    return render_template('login.html', verification_required=False)

@auth_bp.route('/verify_account/<verification_code>', methods=['GET', 'POST'])
def verify_account(verification_code):
    user = User.query.filter_by(verification_code=verification_code).first()
    if user and user.verify_email(verification_code):
        user.is_active = True  # Mark the user as active
        db.session.commit()
        # Set a session variable to indicate login
        session['user_id'] = user.id
        flash('Account verified successfully!', 'success')
        return redirect(url_for('dashboard.dashboard'))  # Redirect to the dashboard
    else:
        flash('Invalid verification code.', 'danger')
        return render_template('enter_verification_code.html', user=user)

@auth_bp.route('/verify_email', methods=['POST'])
def verify_email():
    user_id = request.form.get('user_id')
    entered_code = request.form.get('verification_code')

    user = User.query.get(user_id)

    if user and user.verify_email(entered_code):
        flash('Email verified successfully!', 'success')
        return redirect(url_for('dashboard.dashboard'))
    else:
        flash('Invalid verification code.', 'danger')
        return render_template('enter_verification_code.html', user=user, code_error='Invalid verification code.')



# Add a new route for verifying the verification code
@auth_bp.route('/verify_code', methods=['POST'])
def verify_code():
    user_id = request.form.get('user_id')
    entered_code = request.form.get('verification_code')

    user = User.query.get(user_id)

    if user and user.verify_email(entered_code):
        user.is_active = True  # Mark the user as active
        db.session.commit()

        flash('Email verified successfully!', 'success')
        return redirect(url_for('dashboard.dashboard'))
    else:
        flash('Invalid verification code.', 'danger')
        return render_template('enter_verification_code.html', user=user, code_error='Invalid verification code.')



@auth_bp.route('/account_created')
def account_created():
    return render_template('account_created.html')

@auth_bp.route('/logout')
def logout():
    # Logout logic: Clear the user session variable
    session.pop('user_id', None)
    flash('Logged out successfully', 'success')
    return redirect('/')
