from flask import current_app
import smtplib
from email.message import EmailMessage

def send_verification_email(email, verification_code):
    msg = EmailMessage()
    msg.set_content(f'Your verification code is: {verification_code}')
    msg['Subject'] = 'Verify Your Email'
    msg['From'] = 'personalincomexpensetracker@gmail.com'
    msg['To'] = email

    try:
        smtp_server = smtplib.SMTP('smtp.gmail.com', 587)
        smtp_server.starttls()
        smtp_server.login('personalincomexpensetracker@gmail.com', 'cclfcpaaosprdwsx')  # Replace with your Gmail credentials
        smtp_server.send_message(msg)
        smtp_server.quit()
        return True
    except Exception as e:
        print(f"Email sending failed: {e}")
        return False


def send_account_created_email(email):
    msg = EmailMessage()
    msg.set_content('Your account has been created successfully.')
    msg['Subject'] = 'Account Created Successfully'
    msg['From'] = 'personalincomexpensetracker@gmail.com'
    msg['To'] = email

    try:
        smtp_server = smtplib.SMTP('smtp.gmail.com', 587)
        smtp_server.starttls()
        smtp_server.login('personalincomexpensetracker@gmail.com', 'cclfcpaaosprdwsx')  # Replace with your Gmail credentials
        smtp_server.send_message(msg)
        smtp_server.quit()
        return True
    except Exception as e:
        print(f"Email sending failed: {e}")
        return False