# budgets.py
from flask import Blueprint, render_template, redirect, url_for, flash, session, request, jsonify
from .models import db, User, Budget

budgets_bp = Blueprint('budgets', __name__,static_url_path='/static')

@budgets_bp.route('/set_budget', methods=["GET", "POST"])
def set_budget():
    if request.method == "POST":
        # Retrieve the submitted category and budget from the form
        category = request.form.get("category")
        amount = float(request.form.get("budget"))
        description = request.form['description']
        other_category = None
        
        if category == 'Other':
            other_category = request.form['other_category']
        
        # Check if the user is logged in
        if 'user_id' not in session:
            return redirect('/')

        # Get the logged-in user's user_id
        user_id = session['user_id']

        # Get the user object from the database
        user = User.query.filter_by(id=user_id).first()
        
        # Create a new Budget object and save it to the database
        budget = Budget(user_id=user.id, category=category, amount=amount, description=description, other_category=other_category)
        db.session.add(budget)
        db.session.commit()

        # Redirect to the "View Budget" page to see the saved budget data
        return redirect(url_for("budgets.view_budget"))

    # For GET request, render the form with empty fields
    return render_template("set_budget.html")


@budgets_bp.route('/view_budget', methods=['GET','POST'])
def view_budget():
    if 'user_id' not in session:
        return redirect('/')
    
    # Get the logged-in user's user_id
    user_id = session['user_id']

    # Retrieve the user from the database
    user = User.query.get(user_id)

    # Retrieve all budget items associated with the user
    budgets = Budget.query.filter_by(user_id=user.id).all()

    for budget in budgets:
        if budget.category == 'Other':
            budget.category = budget.other_category
            
    return render_template("view_budget.html", budgets=budgets)

@budgets_bp.route('/edit_budget/<int:budget_id>', methods=['GET', 'POST'])
def edit_budget(budget_id):
    # Check if the user is logged in
    if 'user_id' not in session:
        return redirect('/')

    # Get the logged-in user's user_id
    user_id = session['user_id']

    # Retrieve the user from the database
    user = User.query.get(user_id)

    # Get the budget object based on budget_id
    budget = Budget.query.get(budget_id)

    if not budget:
        flash('Budget not found.', 'danger')
        return redirect('/view_budget')

    # Handle form submission
    if request.method == 'POST':
        # Get the updated budget details from the form
        budget.category = request.form['category']
        budget.amount = float(request.form['amount'])  # Convert to float
        budget.description = request.form['description']
        
        # Set other_category only if the category is 'Other'
        if budget.category == 'Other':
            budget.other_category = request.form['other_category']
        else:
            budget.other_category = None

        # Commit the changes to the database
        db.session.commit()
        flash('Budget updated successfully.', 'success')

        return redirect('/view_budget')

    # Pass the budget object and user to the template for editing
    return render_template('edit_budget.html', budget=budget, user=user)

@budgets_bp.route('/delete_budget/<int:budget_id>', methods=['POST'])
def delete_budget(budget_id):
    # Check if the user is logged in
    if 'user_id' not in session:
        return redirect('/')

    # Get the logged-in user's user_id
    user_id = session['user_id']

    # Retrieve the user from the database
    user = User.query.get(user_id)

    # Get the budget object based on budget_id
    budget = Budget.query.get(budget_id)

    if not budget:
        flash('Budget not found.', 'danger')
    else:
        # Delete the budget from the database
        db.session.delete(budget)
        db.session.commit()
        flash('Budget deleted successfully.', 'success')

    return jsonify({'success': True, 'message': 'Budget deleted successfully'})

