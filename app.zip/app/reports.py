# reports.py
from flask import Blueprint, render_template, redirect, url_for, flash, session, request, jsonify
from .models import User, Expense, Income
from .utils import calculate_total_expenses, calculate_expenses_by_category, calculate_total_income, calculate_income_by_source,aggregate_income_for_pie_chart,aggregate_expense_for_pie_chart
from sqlalchemy import asc,desc
from datetime import datetime
import matplotlib.pyplot as plt
import base64
from io import BytesIO



reports_bp = Blueprint('reports', __name__,static_url_path='/static')
income_data = [
    {'source': 'Source 1', 'amount': 100.0, 'date': '2023-09-01'},
    {'source': 'Source 2', 'amount': 150.0, 'date': '2023-09-02'},
    # Add more income items as dictionaries
]


@reports_bp.route('/view_reports', methods=['GET', 'POST'])
def view_reports():
    # Check if the user is logged in
    if 'user_id' not in session:
        return redirect('/')

    user_id = session['user_id']

    # Get the user object from the database
    user = User.query.filter_by(id=user_id).first()

    if not user:
        # Handle the case where the user doesn't exist (possibly log an error)
        return redirect('/')

    if request.method == 'POST':
        report_type = request.form.get('report_type')

        if report_type == 'income':
            # Calculate total income for the logged-in user
            total_income = calculate_total_income(user_id)
            

            # Calculate income by source for the logged-in user
            income_data = calculate_income_by_source(user_id)
            aggregated_income_data = aggregate_income_for_pie_chart(income_data)
            
            

            # Retrieve sort options from the form
            sort_by = request.form.get('sort_by')
            sort_order = request.form.get('sort_order')

            # Sort the income_data based on the user's choice
            if sort_by == 'amount':
                income_data = dict(sorted(income_data.items(), key=lambda x: sum(e['amount'] for e in x[1]), reverse=(sort_order == 'desc')))
            elif sort_by == 'date':
                income_data = dict(sorted(income_data.items(), key=lambda x: max(e['date'] for e in x[1]), reverse=(sort_order == 'desc')))
            
            
            

            # Initialize dictionaries to store aggregated data
            source_names = list(aggregated_income_data.keys())
            source_amounts = list(aggregated_income_data.values())
            # Create the pie chart
            plt.figure(figsize=(8, 8))
            plt.pie(source_amounts, labels=source_names, autopct='%1.1f%%', startangle=140)
            plt.title('Income by Source')

            # Convert the chart to a base64-encoded image
            img_data = BytesIO()
            plt.savefig(img_data, format='png')
            img_data.seek(0)
            pie_chart_base64 = base64.b64encode(img_data.read()).decode('utf-8')

            # Render the template with the updated data
            return render_template('view_income_reports.html', total_income=total_income, income_data=income_data, pie_chart_base64=pie_chart_base64)
        
        if report_type == 'expense':
            total_expense = calculate_total_expenses(user_id)
            expense_data = calculate_expenses_by_category(user_id)
            aggregated_expense_data = aggregate_expense_for_pie_chart(expense_data)

            # Retrieve sort options from the form
            sort_by = request.form.get('sort_by')
            sort_order = request.form.get('sort_order')

            if sort_by == 'amount':
                expense_data = dict(sorted(expense_data.items(), key=lambda x: sum(e['amount'] for e in x[1]), reverse=(sort_order == 'desc')))
            elif sort_by == 'date':
                expense_data = dict(sorted(expense_data.items(), key=lambda x: max(e['date'] for e in x[1]), reverse=(sort_order == 'desc')))

            # Create the pie chart for expenses
            plt.figure(figsize=(8, 8))
            plt.pie(list(aggregated_expense_data.values()), labels=list(aggregated_expense_data.keys()), autopct='%1.1f%%', startangle=140)
            plt.title('Expense by Category')

            # Convert the chart to a base64-encoded image
            img_data = BytesIO()
            plt.savefig(img_data, format='png')
            img_data.seek(0)
            pie_chart_base64 = base64.b64encode(img_data.read()).decode('utf-8')

             # Render the template with the updated data
            return render_template('view_expense_reports.html', total_expense=total_expense, expense_data=expense_data, pie_chart_base64=pie_chart_base64)


    return render_template('view_reports.html')  


    pass


