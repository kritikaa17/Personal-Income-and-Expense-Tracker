# charts.py
from flask import Blueprint, render_template, request
from matplotlib import pyplot as plt
from .models import Expense, Income, Budget
from io import BytesIO
from sqlalchemy import asc
import base64



charts_bp = Blueprint('charts', __name__,static_url_path='/static')

@charts_bp.route('/generate_charts', methods=['GET','POST'])
def generate_charts():
    if request.method == 'POST':
        chart_type = request.form.get('chart_type')
        
        if chart_type == 'income_vs_expense':
            # Retrieve income and expense data from the database and sort by date
            incomes = Income.query.order_by(asc(Income.date)).all()
            expenses = Expense.query.order_by(asc(Expense.date)).all()

            # Extract amounts and dates from income and expense data
            income_amounts = [income.amount for income in incomes]
            expense_amounts = [expense.amount for expense in expenses]
            income_dates = [income.date for income in incomes]
            expense_dates = [expense.date for expense in expenses]

            # Group income and expense data by month or year (customize this as needed)
            # Here, we're assuming the date format is 'YYYY-MM'
            income_by_month = {}
            expense_by_month = {}

            for i in range(len(income_dates)):
                year_month = income_dates[i]
                if year_month not in income_by_month:
                    income_by_month[year_month] = 0
                income_by_month[year_month] += income_amounts[i]

            for i in range(len(expense_dates)):
                year_month = expense_dates[i]
                if year_month not in expense_by_month:
                    expense_by_month[year_month] = 0
                expense_by_month[year_month] += expense_amounts[i]

            # Extract unique time periods (months or years)
            time_periods = list(set(income_dates + expense_dates))
            time_periods.sort()  # Sort the time periods chronologically

            # Extract income and expense amounts for each time period
            income_by_period = [income_by_month.get(period, 0) for period in time_periods]
            expense_by_period = [expense_by_month.get(period, 0) for period in time_periods]

            # Create the line graph
            plt.figure(figsize=(12, 6))

            plt.plot(time_periods, income_by_period, label='Income', marker='o', color='blue')
            plt.plot(time_periods, expense_by_period, label='Expense', marker='o', color='red')

            plt.xlabel('Time Period')
            plt.ylabel('Amount ($)')
            plt.title('Income vs. Expense Over Time')
            plt.legend()
            plt.grid(True)
            plt.xticks(rotation=45)

            # Convert the chart to a base64-encoded image
            img_data = BytesIO()
            plt.savefig(img_data, format='png')
            img_data.seek(0)
            img_base64 = base64.b64encode(img_data.read()).decode('utf-8')

            # Render the chart as an image in an HTML template
            return render_template('charts.html', chart_image=img_base64)

        

        elif chart_type == 'budget_vs_expense':
            # Retrieve expense and budget data from the database
            expenses = Expense.query.all()
            budgets = Budget.query.all()

            # Use sets to keep track of unique categories
            expense_categories_set = set()
            budget_categories_set = set()

            # Extract categories, amounts, and dates from expense and budget data
            expense_amounts = []
            budget_amounts = []

            for expense in expenses:
                if expense.other_category:
                    expense_categories_set.add(expense.other_category)  # Use other_category if available
                else:
                    expense_categories_set.add(expense.category)
                expense_amounts.append(expense.amount)

            for budget in budgets:
                if budget.other_category:
                    budget_categories_set.add(budget.other_category)  # Use other_category if available
                else:
                    budget_categories_set.add(budget.category)
                budget_amounts.append(budget.amount)

            # Convert sets to sorted lists for plotting
            expense_categories = sorted(list(expense_categories_set))
            budget_categories = sorted(list(budget_categories_set))

            # Create dictionaries to store total expense and budget amounts by category
            expense_totals = {category: 0.0 for category in expense_categories}
            budget_totals = {category: 0.0 for category in budget_categories}

            # Aggregate expense amounts by category
            for expense, amount in zip(expenses, expense_amounts):
                if expense.other_category:
                    category = expense.other_category
                else:
                    category = expense.category
                expense_totals[category] += amount

            # Aggregate budget amounts by category
            for budget, amount in zip(budgets, budget_amounts):
                if budget.other_category:
                    category = budget.other_category
                else:
                    category = budget.category
                budget_totals[category] += amount

            # Convert dictionaries to lists for plotting
            expense_totals_list = [expense_totals[category] for category in expense_categories]
            budget_totals_list = [budget_totals[category] for category in budget_categories]

            # Create the bar chart for budget vs. expense (by category)
            plt.figure(figsize=(12, 6))
            width = 0.4
            x = range(len(expense_categories))

            plt.bar(x, budget_totals_list, width=width, label='Budget', color='#00008B')
            plt.bar([i + width for i in x], expense_totals_list, width=width, label='Expense', color='#ADD8E6')

            # Customize the x-axis labels to show the categories with rotated labels
            plt.xticks([i + width / 2 for i in x], expense_categories, rotation=10, ha='right')

            plt.xlabel('Category')
            plt.ylabel('Amount')
            plt.title('Budget vs. Expense by Category')
            plt.legend()
            plt.grid(True)

            # Add labels for amount and category
            plt.xlabel('Category')
            plt.ylabel('Amount')

            # Convert the chart to a base64-encoded image
            img_data = BytesIO()
            plt.savefig(img_data, format='png')
            img_data.seek(0)
            img_base64 = base64.b64encode(img_data.read()).decode('utf-8')

            # Render the chart as an image in an HTML template
            return render_template('charts.html', chart_image=img_base64)
    
        elif chart_type == 'daily_expenses':
            # Retrieve expense data from the database and sort by date
            expenses = Expense.query.order_by(asc(Expense.date)).all()

            # Extract date and amount from expense data
            expense_dates = [expense.date for expense in expenses]
            expense_amounts = [expense.amount for expense in expenses]

            # Create the line graph for daily expenses
            plt.figure(figsize=(12, 6))

            plt.plot(expense_dates, expense_amounts, marker='o', color='blue')

            plt.xlabel('Date')
            plt.ylabel('Amount')
            plt.title('Daily Expenses Over Time')
            plt.grid(True)

            # Rotate x-axis labels for readability (customize as needed)
            plt.xticks(rotation=45)

            # Convert the chart to a base64-encoded image
            img_data = BytesIO()
            plt.savefig(img_data, format='png')
            img_data.seek(0)
            img_base64 = base64.b64encode(img_data.read()).decode('utf-8')

            # Render the chart as an image in an HTML template
            return render_template('charts.html', chart_image=img_base64)

    # Render the initial chart selection page
    return render_template('chart_selection.html')

    pass

# Add more chart-related routes and functions as needed
